
// Data daftar buku
const daftarBuku = [
    { judul: 'Laskar Pelangi', harga: 85000, stok: 5, kategori: 'Novel' },
    { judul: 'Filosofi Teras', harga: 98000, stok: 0, kategori: 'Self-Help' },
    { judul: 'Atomic Habits', harga: 120000, stok: 3, kategori: 'Self-Help' },
    { judul: 'Bumi Manusia', harga: 105000, stok: 2, kategori: 'Novel' }
];

// A. Menampilkan buku yang stoknya tersedia
const bukuTersedia = daftarBuku
    .filter(buku => buku.stok > 0)
    .map(buku => buku.judul);

document.getElementById('tersedia').textContent =
    bukuTersedia.join('\n');

// B. Menghitung total harga seluruh buku menggunakan reduce
const totalHarga = daftarBuku.reduce(
    (total, buku) => total + buku.harga, 0
);

document.getElementById('total').textContent =
    'Rp' + totalHarga.toLocaleString('id-ID');

// C. Menampilkan daftar semua buku
let daftar = '';

daftarBuku.forEach(buku => {
    daftar += `${buku.judul} - Rp${buku.harga} (Stok: ${buku.stok})\n`;
});

document.getElementById('daftar').textContent = daftar;

// D. Fungsi proses pembayaran menggunakan Promise
function prosesPembayaran(judulBuku) {
    return new Promise((resolve, reject) => {

        setTimeout(() => {
            const buku = daftarBuku.find(
                item => item.judul === judulBuku
            );

            if (buku && buku.stok > 0) {
                resolve(
                    'Pembayaran berhasil untuk buku: ' + buku.judul
                );
            } else {
                reject(
                    'Gagal: Buku tidak tersedia atau stok habis!'
                );
            }

        }, 1500);
    });
}

// E. Fungsi async untuk menguji pembayaran
async function transaksiToko() {
    const output = document.getElementById('pembayaran');

    output.textContent = 'Memproses Atomic Habits...\n';

    try {
        const hasil = await prosesPembayaran('Atomic Habits');
        output.textContent += hasil + '\n';
    } catch (error) {
        output.textContent += error + '\n';
    }

    output.textContent += '\nMemproses Filosofi Teras...\n';

    try {
        const hasil = await prosesPembayaran('Filosofi Teras');
        output.textContent += hasil + '\n';
    } catch (error) {
        output.textContent += error + '\n';
    }
}

// Menjalankan program
transaksiToko();
