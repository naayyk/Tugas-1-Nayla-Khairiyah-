
// Fungsi untuk menunggu beberapa waktu
function tunggu(ms) {
    return new Promise(resolve => {
        setTimeout(resolve, ms);
    });
}

// Fungsi Async dan Await
async function jalankanProses() {
    const output = document.getElementById('output');

    output.textContent += "Mulai\n";

    await tunggu(1000);
    output.textContent += "Langkah 1\n";

    await tunggu(1000);
    output.textContent += "Selesai\n";
}

// Fungsi untuk mengecek stok barang
function cekStok(jumlah) {
    return new Promise((resolve, reject) => {
        if (jumlah > 0) {
            resolve("Stok tersedia: " + jumlah);
        } else {
            reject("Stok habis!");
        }
    });
}

// Menggunakan Async, Await, dan Try Catch
async function periksaStok() {
    const stok = document.getElementById('stok');

    try {
        const hasil = await cekStok(5);
        stok.textContent += hasil + "\n";
    } catch (error) {
        stok.textContent += error + "\n";
    }

    try {
        const hasil = await cekStok(0);
        stok.textContent += hasil + "\n";
    } catch (error) {
        stok.textContent += error + "\n";
    }
}

// Menjalankan program
jalankanProses();
periksaStok();
