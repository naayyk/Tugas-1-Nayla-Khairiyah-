
const produk = [
    { nama: 'Pensil', harga: 2000, stok: 10 },
    { nama: 'Buku', harga: 5000, stok: 0 },
    { nama: 'Penghapus', harga: 1500, stok: 5 },
];

// A. Menampilkan produk dengan stok lebih dari 0
const produkTersedia = produk
    .filter(item => item.stok > 0)
    .map(item => item.nama);

document.getElementById('stok').innerHTML =
    produkTersedia.join(', ');

// B. Mencari produk bernama Penghapus
const cariProduk = produk.find(
    item => item.nama === 'Penghapus'
);

document.getElementById('cari').innerHTML =
    `Nama: ${cariProduk.nama}<br>
     Harga: Rp${cariProduk.harga}<br>
     Stok: ${cariProduk.stok}`;

// C. Menampilkan semua produk
let daftar = '<ul>';

produk.forEach(item => {
    daftar += `<li>${item.nama} - Rp${item.harga}</li>`;
});

daftar += '</ul>';

document.getElementById('daftar').innerHTML = daftar;
